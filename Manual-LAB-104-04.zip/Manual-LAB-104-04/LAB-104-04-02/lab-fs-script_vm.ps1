<#	
	Version:        3.0
	Author:         Ahmad Majeed Zahoory
	Creation Date:  26th January, 2024
	Purpose/Change: Creating Windows & Linux Virtual Machine
#>

# Variables for common values
$resourceGroup = "az-fs-rg"
$location = "eastus"
$vmName1 = "windowsvm"
$vmName2 = "linuxvm"
$sku = "Standard_D2s_v3"

# Create a resource group
New-AzResourceGroup -Name $resourceGroup -Location $location

# Definer user name and password
$User = "master"
$Password = ConvertTo-SecureString -String "Lab@password" -AsPlainText -Force
$cred = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $User, $Password

############################################ Virtual Network ######################################################

# Create a subnet configuration
$subnetConfig = New-AzVirtualNetworkSubnetConfig -Name subnet01 -AddressPrefix 192.168.0.0/24

# Create a virtual network
$vnet = New-AzVirtualNetwork -ResourceGroupName $resourceGroup -Location $location `
  -Name az-vnet -AddressPrefix 192.168.0.0/24 -Subnet $subnetConfig

############################################ Public IP Address ######################################################

# Create a public IP address and specify a DNS name
$pip1 = New-AzPublicIpAddress -ResourceGroupName $resourceGroup -Location $location `
  -Name "winvm$(Get-Random)" -AllocationMethod Static -IdleTimeoutInMinutes 4

# Create a public IP address and specify a DNS name
$pip2 = New-AzPublicIpAddress -ResourceGroupName $resourceGroup -Location $location `
  -Name "linvm$(Get-Random)" -AllocationMethod Static -IdleTimeoutInMinutes 4

############################################ Network Security Group & Rule ##########################################

# Create an inbound network security group rule for port 3389
$nsgrulerdp = New-AzNetworkSecurityRuleConfig -Name nsgrulerdp  -Protocol Tcp `
  -Direction Inbound -Priority 1000 -SourceAddressPrefix * -SourcePortRange * -DestinationAddressPrefix * `
  -DestinationPortRange 3389 -Access Allow

# Create an inbound network security group rule for port 22
$nsgrulessh = New-AzNetworkSecurityRuleConfig -Name nsgrulessh  -Protocol Tcp `
  -Direction Inbound -Priority 2000 -SourceAddressPrefix * -SourcePortRange * -DestinationAddressPrefix * `
  -DestinationPortRange 22 -Access Allow

# Create a network security group
$nsg1 = New-AzNetworkSecurityGroup -ResourceGroupName $resourceGroup -Location $location `
  -Name winvmnsg -SecurityRules $nsgrulerdp

# Create a network security group
$nsg2 = New-AzNetworkSecurityGroup -ResourceGroupName $resourceGroup -Location $location `
  -Name linvmnsg -SecurityRules $nsgrulessh
############################################ Network Interface Card ##########################################

# Create a virtual network card and associate with public IP address and NSG
$nic1 = New-AzNetworkInterface -Name winvmnic -ResourceGroupName $resourceGroup -Location $location `
  -SubnetId $vnet.Subnets[0].Id -PublicIpAddressId $pip1.Id -NetworkSecurityGroupId $nsg1.Id

# Create a virtual network card and associate with public IP address and NSG
$nic2 = New-AzNetworkInterface -Name linvmnic -ResourceGroupName $resourceGroup -Location $location `
  -SubnetId $vnet.Subnets[0].Id -PublicIpAddressId $pip2.Id -NetworkSecurityGroupId $nsg2.Id

############################################ Windows Virtual Machine ######################################################

# Create a virtual machine configuration
$vmConfig1 = New-AzVMConfig -VMName $vmName1 -VMSize $sku | `
Set-AzVMOperatingSystem -Windows -ComputerName $vmName1 -Credential $cred | `
Set-AzVMSourceImage -PublisherName MicrosoftWindowsServer -Offer WindowsServer -Skus 2022-Datacenter -Version latest | `
Add-AzVMNetworkInterface -Id $nic1.Id

# Create a virtual machine
New-AzVM -ResourceGroupName $resourceGroup -Location $location -VM $vmConfig1


############################################ Red Hat Virtual Machine ######################################################

# Create a virtual machine configuration
$vmConfig2 = New-AzVMConfig -VMName $vmName2 -VMSize $sku | `
Set-AzVMOperatingSystem -Linux -ComputerName $vmName2 -Credential $cred | `
Set-AzVMSourceImage -PublisherName RedHat -Offer RHEL -Skus 9_2 -Version latest | `
Add-AzVMNetworkInterface -Id $nic2.Id

# Create a virtual machine
New-AzVM -ResourceGroupName $resourceGroup -Location $location -VM $vmConfig2

# End